#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main() {
    string cur;
    
    int result = 0;
    
    int lines = 0;
    
    while(++lines < 220){
    	bool winningNoLogged = false;
    	int score = 0, cnt = 0, numsFound = 0;
    	unordered_set<string> winningNo;
    		
    	while (++cnt<39 ) {
    		string str;
		cin >> str;
		
    		if(cnt<=2){
    			cout<<str<< " ";
    			continue;
    		}
    			
		if(str == "|"){
			winningNoLogged = true;
			continue;
		}
		
    		if(!winningNoLogged){ 
    			winningNo.insert(str);
    			
    			continue;
    		}
    		if(winningNo.count(str)){
    			//cout<< "found: "<< str<<endl;
    			score = pow(2, numsFound++);
    		}
    	}
    	result += score;
    	cout<< "score: "<<score<<endl;
		
    }
    cout<< "final result: "<< result<< endl;
    
    return 0;
}
