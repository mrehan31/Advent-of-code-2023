#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main() {
    string cur;
    int originalCard = 1;
    
    int result = 0;
    
    int lines = 0;
    
    unordered_map<int, int>allCards;
    
    while(++lines < 220){
    	bool winningNoLogged = false;
    	int score = 0, matchingCardsCnt = 0, numsFound = 0;
    	int cnt = 0;
    	unordered_set<string> winningNo;

    	allCards[originalCard]++;
    		
    	while (++cnt<39 ) {
    		string str;
		cin >> str;
		
    		if(cnt<=2){
    			continue;
    		}
    			
		if(str == "|"){
			winningNoLogged = true;
			continue;
		}
		
    		if(!winningNoLogged){ 
    			winningNo.insert(str);
    			
    			continue;
    		}
    		if(winningNo.count(str)){
			matchingCardsCnt++;
    		}
    	}
    	int cardCnt = allCards[originalCard];
    	
    	while(matchingCardsCnt){
    		allCards[originalCard + matchingCardsCnt] += cardCnt;
    		matchingCardsCnt--;
    	}
    	originalCard++;    		
    }
    for(auto it:allCards){
    	result += it.second;
    }
    
    cout<< "final result: "<< result<< endl;
    
    return 0;
}
