#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int findNo(string &str, map<string, int> &map){
	vector<pair<int, int>> nums;
	
	for(auto &it: map){
		string searchKey = it.first;
		if(searchKey.size() > str.size())	continue;
		
		for(int i = 0; i<(str.size() - searchKey.size() + 1); i++){
			if(str.substr(i, searchKey.size()) == searchKey){
				nums.push_back({i, it.second});
			}
		}
	}
	sort(nums.begin(), nums.end());
	return nums[0].second*10 + nums.back().second;
}

int main() {
    string cur;
    int count = 0;
    unsigned long result = 0; 
    map<string, int> map;
    map = {{"1", 1}, {"2", 2}, {"3", 3}, {"4", 4}, {"5", 5}, {"6", 6}, {"7", 7}, {"8", 8}, {"9", 9}, {"one", 1}, {"two", 2}, {"three", 3}, {"four", 4}, {"five", 5}, {"six", 6}, {"seven", 7}, {"eight", 8}, {"nine", 9}};
    
    while (true) {
        cin >> cur;
        int ret = findNo(cur, map);
        result += ret;
        cout<<"count: "<< count<<", "<<cur<<", No: "<< ret<< endl;
        if(++count == 1000)	break;
    }
    cout<<"final result: "<< result;
    return result;
}
