#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int findNo(string str){
	int first, last;
	
	for(int i=0; i<str.size(); i++){
		if(str[i]>='0' && str[i] <= '9'){
			first = str[i] - '0';
			break;
		}
	}
	
	for(int i = str.size()-1; i>=0; i--){
		if(str[i]>='0' && str[i] <= '9'){
			last = str[i] - '0';
			break;
		}
	}
	return first*10 + last;
}

int main() {
    string cur;
    int count = 0;
    unsigned long result = 0; 
    
    while (true) {
        cin >> cur;
        int ret = findNo(cur);
        result += ret;
        cout<<"count: "<< count<<", "<<cur<<", No: "<< ret<< endl;
        if(++count == 1000)	break;
    }
    cout<<"final result: "<< result;
    return result;
}
