#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main() {
    string cur;
    
    int res = 0;
    
    
    while (true) {
    	string str;
    	int game_id;
    	unordered_map<string, int>map;
  
    	
    	while(true){
    		cin >> str;
    		if(str == "Game")	continue;
    		
    		if(str.back() == ':'){
    			str.pop_back();
    			game_id = stoi(str);
    			cout<<"game id: "<< game_id<< endl;
    			continue;
    		}
    		
    		if(str.back() >= '0' && str.back() <= '9'){
    			int curCount = stoi(str);
    			cin >> str;
    			cout<< "cur Count: "<<curCount<<", " << str<< endl;
    			
   			map[str.substr(0, 3)] = max(map[str.substr(0, 3)], curCount);
    		}
    		

    		if(str.back() != ',' && str.back() != ';'){
    			int curProd = 1;
    			
			for(auto it: map)	curProd *= it.second;
			
			cout<<"curProd: "<< curProd << endl;			
			res += curProd;
			
    			break;
    		}
   	}
   	if(game_id >= 100)	break;
    }
    cout<< "final result: "<< res<< endl;
    
    return 0;
}
