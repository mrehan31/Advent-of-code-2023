#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main() {

    unsigned long result = 0;
    int cnt = 0;
    vector<vector<int>> dir = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    vector<string> input;
    string str;
    unordered_set<char> set;
        
    while (true) {
    	cin >> str;
    	input.push_back(str);
    	for(char ch: str){
    		if(ch != '.' && (ch < '0' || ch > '9'))	set.insert(ch);
    	}
    	
      	if(++cnt >= 140)	break;
    }
    
    for(int i=0;i<input.size(); i++){
    	for(int j=0; j<input[i].size(); j++){
    		bool flag = false;
    		unsigned long num = 0;
    		
    		if(input[i][j] >='0' && input[i][j] <= '9'){
    			while(j<input[i].size() && input[i][j] >='0' && input[i][j] <= '9'){
    				num *= 10;
    				num += input[i][j] - '0';
    				for(auto d: dir){
    					int r = i + d[0], c = j + d[1];
    					if(r>=0 && r<input.size() && c>=0 && c<=input[i].size() && set.count(input[r][c])) 
    						flag = true;
    				}
    				j++;
    			}
    			
    			if(flag){
    				cout<<"good num: "<< num<< endl;
    				result += num;	
    			}
    			
    		}
    	}
    }
    cout<< "result: "<< result; 
    return 0;
}
